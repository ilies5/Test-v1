import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final today = DateFormat('EEEE, d MMMM', 'ar').format(DateTime.now());

    return Scaffold(
      appBar: AppBar(
        title: const Text('Life Manager'),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('صباح الخير 👋', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 4),
          Text(today),
          const SizedBox(height: 20),
          _sectionTitle(context, 'نظرة اليوم'),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _metricCard(context, 'المهام', '3 / 5', Icons.task_alt)),
              const SizedBox(width: 10),
              Expanded(child: _metricCard(context, 'الأهداف', '4 نشطة', Icons.flag_outlined)),
            ],
          ),
          const SizedBox(height: 16),
          _financeCard(context),
          const SizedBox(height: 20),
          _sectionTitle(context, 'مهام اليوم'),
          const SizedBox(height: 10),
          _taskTile(context, 'مراجعة أهداف الأسبوع', '09:00', true),
          _taskTile(context, '30 دقيقة فرنسية', '18:00', false),
          _taskTile(context, 'تسجيل مصاريف اليوم', '21:00', false),
          const SizedBox(height: 20),
          _sectionTitle(context, 'أهداف قريبة'),
          const SizedBox(height: 10),
          _goalTile(context, 'تعلم الفرنسية', 0.45),
          _goalTile(context, 'ادخار السيارة', 0.20),
          const SizedBox(height: 20),
          _sectionTitle(context, 'ملخص الأسبوع'),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: const [
                  _Stat(value: '18', label: 'مهمة'),
                  _Stat(value: '13', label: 'مكتملة'),
                  _Stat(value: '8,500 DA', label: 'مصروف'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const Text('إضافة'),
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String text) =>
      Text(text, style: Theme.of(context).textTheme.titleLarge);

  Widget _metricCard(BuildContext context, String title, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon),
            const SizedBox(height: 10),
            Text(title),
            const SizedBox(height: 4),
            Text(value, style: Theme.of(context).textTheme.titleLarge),
          ],
        ),
      ),
    );
  }

  Widget _financeCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('المال هذا الشهر', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 14),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _Money(label: 'الدخل', value: '80,000 DA'),
                _Money(label: 'المصروف', value: '32,500 DA'),
                _Money(label: 'المتبقي', value: '47,500 DA'),
              ],
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(8)),
              child: LinearProgressIndicator(value: 0.406, minHeight: 8),
            ),
          ],
        ),
      ),
    );
  }

  Widget _taskTile(BuildContext context, String title, String time, bool done) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(done ? Icons.check_circle : Icons.radio_button_unchecked),
        title: Text(title),
        trailing: Text(time),
      ),
    );
  }

  Widget _goalTile(BuildContext context, String title, double progress) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title),
                Text('${(progress * 100).round()}%'),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: progress),
          ],
        ),
      ),
    );
  }
}

class _Money extends StatelessWidget {
  final String label;
  final String value;
  const _Money({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [Text(label), const SizedBox(height: 4), Text(value)],
      );
}

class _Stat extends StatelessWidget {
  final String value;
  final String label;
  const _Stat({required this.value, required this.label});

  @override
  Widget build(BuildContext context) => Column(
        children: [Text(value, style: Theme.of(context).textTheme.titleMedium), Text(label)],
      );
}
