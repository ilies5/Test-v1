class Goal {
  final String id;
  final String title;
  final double progress;
  final DateTime? targetDate;

  const Goal({
    required this.id,
    required this.title,
    this.progress = 0,
    this.targetDate,
  });
}
