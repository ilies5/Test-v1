class Task {
  final String id;
  final String title;
  final DateTime dueDate;
  final bool completed;
  final int priority;

  const Task({
    required this.id,
    required this.title,
    required this.dueDate,
    this.completed = false,
    this.priority = 1,
  });
}
