# Life Manager V1

تطبيق شخصي لإدارة الحياة: الأهداف، التخطيط، المهام، المال والملاحظات.

## التقنية
- Flutter / Dart
- Material 3
- Riverpod
- SQLite عبر sqflite
- بنية features + data + core

## الحالة
هذه حزمة Foundation V1 ليتم وضعها داخل مشروع Flutter حقيقي تم إنشاؤه بواسطة `flutter create`.

## الخطوات
1. `flutter create life_manager`
2. استبدل `pubspec.yaml` و`lib/` بالملفات الموجودة هنا.
3. `flutter pub get`
4. `flutter run`

## المراحل التالية
1. Repository layer
2. Riverpod providers
3. CRUD حقيقي للمهام والأهداف
4. Finance transactions + budgets
5. Calendar
6. Notes
7. Statistics
8. Tests
